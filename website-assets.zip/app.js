"use strict";
const lightbox=document.querySelector('#lightbox');
const image=document.querySelector('#lightbox-image');
document.querySelectorAll('[data-image]').forEach(button=>button.addEventListener('click',()=>{
 image.src=button.dataset.image;image.alt=button.dataset.caption;
 document.querySelector('#lightbox-caption').textContent=button.dataset.caption;lightbox.showModal();
}));
document.querySelector('#close-lightbox').addEventListener('click',()=>lightbox.close());
lightbox.addEventListener('click',event=>{if(event.target===lightbox)lightbox.close();});
const button=document.querySelector('#download-game'),label=document.querySelector('#download-label'),status=document.querySelector('#download-status');
let release;
async function loadRelease(){
 if(release)return release;
 const response=await fetch('/downloads/release.json');if(!response.ok)throw new Error('release');
 const data=await response.json();
 if(!data.url.startsWith('https://github.com/fankroman4-byte/dead-island-website/releases/download/'))throw new Error('url');
 release=data;document.querySelector('#download-size').textContent='ZIP · '+(data.bytes/1048576).toFixed(1)+' МБ';return data;
}
loadRelease().catch(()=>{});
button.addEventListener('click',async()=>{
 button.disabled=true;label.textContent='ОТКРЫВАЕМ ЗАГРУЗКУ…';
 try{
  const data=await loadRelease();const link=document.createElement('a');
  link.href=data.url;link.download=data.filename;document.body.append(link);link.click();link.remove();
  label.textContent='СКАЧАТЬ ЕЩЁ РАЗ';status.textContent='Готовая сборка загружается с GitHub Releases. Распакуй весь ZIP и запусти DEAD ISLAND.exe.';
 }catch(e){label.textContent='ПОВТОРИТЬ ЗАГРУЗКУ';status.textContent='Не удалось открыть загрузку. Проверь интернет и повтори.';}
 finally{button.disabled=false;}
});
